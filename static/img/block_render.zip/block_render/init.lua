-- basic block render for mintest by TumeniNodes (c) 2016-2019

minetest.register_node("block_render:basic_block", {
	description = "Basic Block",
	drawtype = "mesh",
	mesh = "minetest_block_render.obj",
	tiles = {"top.png", "bottom.png",
			"right.png", "left.png",
			"back.png", "front.png"},
	groups = {cracky = 3, stone = 1},
	paramtype = "light",
	sunlight_propogates = true,
	paramtype2 = "facedir",
	is_ground_content = false,
	drop = "block_render:basic_block",
	sounds = default.node_sound_stone_defaults(),
	collision_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
		}
	},
	selection_box = {
		type = "fixed",
		fixed =
			{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}
	},
})


-- Minetest automatically converts nodes into a mesh, this means to
-- register a basic node, one can leave out the following parts of this 
-- code:
--[[
	drawtype = "mesh",
	mesh = "minetest_block_render.obj",
	paramtype = "light",
	sunlight_propogates = true,
	collision_box = {
		type = "fixed",
		fixed = {
			{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5},
		}
	},
	selection_box = {
		type = "fixed",
		fixed =
			{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}
	},
]]--

-- so the code would read as:
--[[
minetest.register_node("block_render:basic_block", {
	description = "Basic Block",
	tiles = {"top.png", "bottom.png",
			"right.png", "left.png",
			"back.png", "front.png"},
	groups = {cracky = 3, stone = 1},
	paramtype2 = "facedir",
	is_ground_content = false,
	sounds = default.node_sound_stone_defaults(),
})
]]--
